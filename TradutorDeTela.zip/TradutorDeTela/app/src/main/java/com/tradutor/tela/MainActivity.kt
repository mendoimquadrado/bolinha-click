package com.tradutor.tela

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

/** Tela única: um botão que alterna entre Iniciar e Parar. */
class MainActivity : AppCompatActivity() {

    private lateinit var botao: MaterialButton
    private lateinit var status: TextView
    private lateinit var chaveOcr: MaterialSwitch
    private lateinit var botaoIdiomas: MaterialButton
    private val prefs by lazy { getSharedPreferences(TradutorService.PREFS, MODE_PRIVATE) }
    private var aguardandoAtivacao = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        botao = findViewById(R.id.botao)
        status = findViewById(R.id.status)
        botao.setOnClickListener { aoTocar() }

        chaveOcr = findViewById(R.id.chaveOcr)
        botaoIdiomas = findViewById(R.id.botaoIdiomas)
        val ocrLigado = prefs.getBoolean(TradutorService.CHAVE_OCR, true)
        chaveOcr.isChecked = ocrLigado
        botaoIdiomas.isEnabled = ocrLigado
        chaveOcr.setOnCheckedChangeListener { _, marcado ->
            prefs.edit().putBoolean(TradutorService.CHAVE_OCR, marcado).apply()
            botaoIdiomas.isEnabled = marcado
            TradutorService.instance?.recarregarConfig()
        }
        botaoIdiomas.setOnClickListener { escolherIdiomas() }
    }

    /** O alfabeto latino (inglês, espanhol, francês...) já vem sempre ligado; estes são extras. */
    private fun escolherIdiomas() {
        val codigos = arrayOf("ja", "zh", "ko", "hi")
        val nomes = arrayOf("Japonês", "Chinês", "Coreano", "Hindi (devanágari)")
        val atuais: Set<String> = prefs.getStringSet(TradutorService.CHAVE_IDIOMAS, emptySet()) ?: emptySet()
        val marcados = BooleanArray(codigos.size) { codigos[it] in atuais }

        AlertDialog.Builder(this)
            .setTitle(R.string.ocr_idiomas_titulo)
            .setMultiChoiceItems(nomes, marcados) { _, i, m -> marcados[i] = m }
            .setPositiveButton(R.string.ok) { _, _ ->
                val novo = codigos.filterIndexed { i, _ -> marcados[i] }.toSet()
                prefs.edit().putStringSet(TradutorService.CHAVE_IDIOMAS, novo).apply()
                TradutorService.instance?.recarregarConfig()
            }
            .setNegativeButton(R.string.cancelar, null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        val servico = TradutorService.instance
        if (aguardandoAtivacao && servicoAtivado() && servico != null) {
            // O usuário acabou de ativar o serviço nas configurações: começa direto.
            aguardandoAtivacao = false
            servico.iniciar()
            irParaInicio()
            return
        }
        atualizar()
    }

    private fun aoTocar() {
        val servico = TradutorService.instance

        // Já está traduzindo: o botão é "Parar".
        if (TradutorService.rodando) {
            servico?.parar()
            atualizar()
            return
        }

        // Primeira vez: o Android exige ativar o serviço em Acessibilidade.
        if (!servicoAtivado()) {
            AlertDialog.Builder(this)
                .setTitle(R.string.dialogo_titulo)
                .setMessage(R.string.dialogo_msg)
                .setPositiveButton(R.string.abrir_config) { _, _ ->
                    aguardandoAtivacao = true
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton(R.string.cancelar, null)
                .show()
            return
        }

        if (servico == null) {
            Toast.makeText(this, R.string.aguarde, Toast.LENGTH_SHORT).show()
            return
        }

        servico.iniciar()
        irParaInicio()
    }

    private fun atualizar() {
        val ativado = servicoAtivado()
        val rodando = ativado && TradutorService.rodando
        val cor = if (rodando) R.color.vermelho else R.color.verde

        botao.setText(if (rodando) R.string.parar else R.string.iniciar)
        botao.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, cor))
        botao.setTextColor(Color.WHITE)
        status.setText(
            when {
                rodando -> R.string.status_rodando
                ativado -> R.string.status_parado
                else -> R.string.status_sem_servico
            }
        )
    }

    private fun servicoAtivado(): Boolean {
        val gerenciador = getSystemService(AccessibilityManager::class.java)
        val ativos = gerenciador.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )
        return ativos.any {
            it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == TradutorService::class.java.name
        }
    }

    /** Leva o usuário para a tela inicial do celular. */
    private fun irParaInicio() {
        startActivity(
            Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        )
    }
}
