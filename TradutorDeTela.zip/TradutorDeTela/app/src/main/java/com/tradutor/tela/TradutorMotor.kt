package com.tradutor.tela

import android.os.SystemClock
import android.util.LruCache
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * Descobre o idioma de cada texto e traduz para português (ML Kit, tudo no aparelho).
 * Deve ser usado apenas na thread principal.
 */
class TradutorMotor {

    private val identificador = LanguageIdentification.getClient()
    private val condicoes = DownloadConditions.Builder().build()

    // texto original -> tradução ("" quando não há o que traduzir)
    private val cache = LruCache<String, String>(3000)
    private val emAndamento = HashSet<String>()
    private val esperar = HashMap<String, Long>()

    // Mantém no máximo 4 tradutores carregados na memória.
    private val tradutores = object : LinkedHashMap<String, Translator>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Translator>?): Boolean {
            if (size <= 4) return false
            eldest?.value?.close()
            return true
        }
    }

    // Textos lidos por OCR e textos lidos pela acessibilidade têm cache separado,
    // porque no OCR palavras curtas recebem um "palpite" de idioma.
    private fun chave(texto: String, ocr: Boolean) = if (ocr) "o|$texto" else "t|$texto"

    /** null = ainda não sei; "" = não precisa traduzir; senão, a tradução. */
    fun consultar(texto: String, ocr: Boolean): String? = cache.get(chave(texto, ocr))

    fun pedir(texto: String, ocr: Boolean, aoConcluir: () -> Unit) {
        val k = chave(texto, ocr)
        if (!emAndamento.add(k)) return

        identificador.identifyPossibleLanguages(texto)
            .addOnSuccessListener { lista ->
                val topo = lista.firstOrNull()
                val chancePt = lista.firstOrNull { it.languageTag == "pt" }?.confidence ?: 0f
                // Só traduz quando tem certeza de que NÃO é português.
                var idioma = if (topo != null && topo.confidence >= 0.5f && chancePt < 0.15f) {
                    TranslateLanguage.fromLanguageTag(topo.languageTag)
                } else {
                    null
                }
                // Em jogos e vídeos o texto costuma ser curto ("START", "メニュー"):
                // o detector de idioma desiste, então chutamos pelo alfabeto.
                if (idioma == null && ocr && chancePt < 0.15f) idioma = chutarIdioma(texto)

                if (idioma == null || idioma == TranslateLanguage.PORTUGUESE) {
                    concluir(k, texto, "", aoConcluir)
                } else {
                    traduzir(k, texto, idioma, aoConcluir)
                }
            }
            .addOnFailureListener { emAndamento.remove(k) }
    }

    private fun chutarIdioma(texto: String): String? {
        var kana = 0
        var hangul = 0
        var han = 0
        var devanagari = 0
        var latim = 0
        for (c in texto) {
            if (!c.isLetter()) continue
            when (Character.UnicodeScript.of(c.code)) {
                Character.UnicodeScript.HIRAGANA, Character.UnicodeScript.KATAKANA -> kana++
                Character.UnicodeScript.HANGUL -> hangul++
                Character.UnicodeScript.HAN -> han++
                Character.UnicodeScript.DEVANAGARI -> devanagari++
                Character.UnicodeScript.LATIN -> latim++
                else -> {}
            }
        }
        return when {
            kana > 0 -> TranslateLanguage.JAPANESE
            hangul > 0 -> TranslateLanguage.KOREAN
            devanagari > 0 -> TranslateLanguage.HINDI
            han > 0 -> TranslateLanguage.CHINESE
            latim > 0 && texto.trim().split(' ').size <= 4 -> TranslateLanguage.ENGLISH
            else -> null
        }
    }

    private fun traduzir(k: String, texto: String, idioma: String, aoConcluir: () -> Unit) {
        // Se o download do pacote do idioma falhou há pouco (sem internet), espera um pouco.
        if (SystemClock.elapsedRealtime() < (esperar[idioma] ?: 0L)) {
            emAndamento.remove(k)
            return
        }

        val tradutor = tradutores.getOrPut(idioma) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(idioma)
                    .setTargetLanguage(TranslateLanguage.PORTUGUESE)
                    .build()
            )
        }

        tradutor.downloadModelIfNeeded(condicoes)
            .addOnSuccessListener {
                tradutor.translate(texto)
                    .addOnSuccessListener { saida -> concluir(k, texto, saida, aoConcluir) }
                    .addOnFailureListener { emAndamento.remove(k) }
            }
            .addOnFailureListener {
                esperar[idioma] = SystemClock.elapsedRealtime() + 30_000L
                emAndamento.remove(k)
            }
    }

    private fun concluir(k: String, texto: String, saida: String?, aoConcluir: () -> Unit) {
        emAndamento.remove(k)
        val limpa = saida?.trim().orEmpty()
        // Se a "tradução" é igual ao original (nomes, siglas...), não desenha nada.
        cache.put(k, if (limpa.equals(texto, ignoreCase = true)) "" else limpa)
        aoConcluir()
    }

    fun fechar() {
        tradutores.values.forEach { it.close() }
        tradutores.clear()
        identificador.close()
    }
}
