package com.bolinha.click

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import kotlin.math.roundToInt

class ClickerService : AccessibilityService() {

    companion object {
        var instance: ClickerService? = null
        const val PREFS = "bolinha"
    }

    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    private val wm by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }

    private var gridView: GridView? = null
    private var ball: View? = null
    private var panel: LinearLayout? = null
    private var ballParams: WindowManager.LayoutParams? = null
    private var gridOn = false
    private var editing = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private val r get() = dp(28)
    private val cell get() = dp(48)

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        hideEditor(); instance = null; return super.onUnbind(intent)
    }

    // ---------- Editor (bolinha + grade + botões) ----------
    fun showEditor() {
        if (editing) return
        editing = true
        val dm = resources.displayMetrics
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

        gridView = GridView(this, cell).also {
            it.visibility = if (gridOn) View.VISIBLE else View.GONE
            wm.addView(it, WindowManager.LayoutParams(
                -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT))
        }

        val b = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(170, 255, 40, 80))
                setStroke(dp(3), Color.WHITE)
            }
        }
        val cx = if (prefs.contains("cx")) prefs.getFloat("cx", 0f) else dm.widthPixels / 2f
        val cy = if (prefs.contains("cy")) prefs.getFloat("cy", 0f) else dm.heightPixels / 2f
        val lp = WindowManager.LayoutParams(
            r * 2, r * 2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (cx - r).toInt(); y = (cy - r).toInt() }
        ballParams = lp
        var sx = 0f; var sy = 0f; var px = 0; var py = 0
        b.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; px = lp.x; py = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = px + (ev.rawX - sx).toInt(); lp.y = py + (ev.rawY - sy).toInt()
                    wm.updateViewLayout(b, lp)
                }
                MotionEvent.ACTION_UP -> if (gridOn) {
                    lp.x = ((lp.x + r).toFloat() / cell).roundToInt() * cell - r
                    lp.y = ((lp.y + r).toFloat() / cell).roundToInt() * cell - r
                    wm.updateViewLayout(b, lp)
                }
            }
            true
        }
        ball = b
        wm.addView(b, lp)

        fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { onClick() }
        }
        val pn = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(220, 20, 20, 30))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(btn("Grade") { toggleGrid() })
            addView(btn("Resetar") { resetBall() })
            addView(btn("Salvar") { saveBall() })
        }
        panel = pn
        wm.addView(pn, WindowManager.LayoutParams(
            -2, -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(90) })
    }

    private fun toggleGrid() {
        gridOn = !gridOn
        gridView?.visibility = if (gridOn) View.VISIBLE else View.GONE
    }

    private fun resetBall() {
        val dm = resources.displayMetrics
        ballParams?.let { it.x = dm.widthPixels / 2 - r; it.y = dm.heightPixels / 2 - r; wm.updateViewLayout(ball, it) }
    }

    private fun saveBall() {
        val loc = IntArray(2)
        ball?.getLocationOnScreen(loc)
        prefs.edit().putFloat("cx", (loc[0] + r).toFloat()).putFloat("cy", (loc[1] + r).toFloat()).apply()
        hideEditor()
    }

    fun hideEditor() {
        listOf(ball, panel, gridView).forEach { v -> v?.let { runCatching { wm.removeView(it) } } }
        ball = null; panel = null; gridView = null; editing = false
    }

    // ---------- Tecla física -> toque segurado ----------
    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (editing || !prefs.getBoolean("enabled", false) || !prefs.contains("cx")) return false
        val key = prefs.getInt("key", KeyEvent.KEYCODE_VOLUME_UP)
        if (e.keyCode != key) return false
        when (e.action) {
            KeyEvent.ACTION_DOWN -> if (e.repeatCount == 0) press()
            KeyEvent.ACTION_UP -> release()
        }
        return true // consome o evento: o volume não muda
    }

    private var held = false
    private var inFlight = false
    private var stroke: StrokeDescription? = null
    private val path get() = Path().apply { moveTo(prefs.getFloat("cx", 0f), prefs.getFloat("cy", 0f)) }

    private fun press() {
        held = true
        val s = StrokeDescription(path, 0, 150, true)
        stroke = s
        send(s)
    }

    private fun send(s: StrokeDescription) {
        inFlight = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(s).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { inFlight = false; next() }
                override fun onCancelled(g: GestureDescription?) { inFlight = false; retry() }
            }, null)
        if (!ok) { inFlight = false; retry() }
    }

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    // Se o sistema cancelar o toque (ex.: outro dedo na tela) e o botão ainda
    // estiver pressionado, tenta pressionar de novo.
    private fun retry() {
        stroke = null
        if (held) handler.postDelayed({ if (held && !inFlight && stroke == null) press() }, 40)
    }

    private fun next() {
        val s = stroke ?: return
        if (held) {
            val n = s.continueStroke(path, 0, 150, true)
            stroke = n; send(n)
        } else {
            val n = s.continueStroke(path, 0, 1, false)
            stroke = null; send(n)
        }
    }

    private fun release() {
        held = false
        if (!inFlight) next()
    }
}

class GridView(ctx: Context, private val cell: Int) : View(ctx) {
    private val p = Paint().apply { color = Color.argb(120, 0, 220, 255); strokeWidth = 2f }
    override fun onDraw(c: Canvas) {
        var x = 0f
        while (x < width) { c.drawLine(x, 0f, x, height.toFloat(), p); x += cell }
        var y = 0f
        while (y < height) { c.drawLine(0f, y, width.toFloat(), y, p); y += cell }
    }
}
