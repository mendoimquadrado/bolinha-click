package com.bolinha.click

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences(ClickerService.PREFS, Context.MODE_PRIVATE) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        root.addView(TextView(this).apply { text = "Bolinha Click"; textSize = 26f })
        status = TextView(this).apply { setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "1) Ativar serviço de acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(Switch(this).apply {
            text = "Autoclique ativo"
            isChecked = prefs.getBoolean("enabled", false)
            setPadding(0, pad, 0, pad)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("enabled", on).apply() }
        })

        root.addView(TextView(this).apply { text = "Botão do aparelho que dispara o toque:" })
        val group = RadioGroup(this)
        val up = RadioButton(this).apply { text = "Volume +"; id = 1 }
        val down = RadioButton(this).apply { text = "Volume −"; id = 2 }
        group.addView(up); group.addView(down)
        if (prefs.getInt("key", KeyEvent.KEYCODE_VOLUME_UP) == KeyEvent.KEYCODE_VOLUME_UP) up.isChecked = true else down.isChecked = true
        group.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("key", if (id == 1) KeyEvent.KEYCODE_VOLUME_UP else KeyEvent.KEYCODE_VOLUME_DOWN).apply()
        }
        root.addView(group)

        root.addView(Button(this).apply {
            text = "2) Posicionar bolinha"
            setOnClickListener {
                val svc = ClickerService.instance
                if (svc == null) toast("Ative o serviço de acessibilidade primeiro")
                else { svc.showEditor(); moveTaskToBack(true) }
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val on = ClickerService.instance != null
        status.text = (if (on) "Serviço: conectado ✔" else "Serviço: desligado ✖") +
            (if (prefs.contains("cx")) "\nPosição salva ✔" else "\nPosição ainda não salva")
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
